// Fonctionnement hors connexion. Changer le numéro de VERSION à chaque mise à jour de l'application.
const VERSION = 'atelier-v1';
const FICHIERS = [
  './', 'index.html', 'manifest.webmanifest',
  'icones/icone-192.png', 'icones/icone-512.png', 'icones/icone-masque-512.png', 'icones/apple-touch-icon.png',
  'polices/bricolage-grotesque-latin-600-normal.woff2', 'polices/bricolage-grotesque-latin-800-normal.woff2',
  'polices/atkinson-hyperlegible-latin-400-normal.woff2', 'polices/atkinson-hyperlegible-latin-700-normal.woff2',
  'polices/zilla-slab-latin-700-normal.woff2'
];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => c.addAll(FICHIERS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
// Réseau d'abord (pour recevoir les mises à jour), sinon la copie gardée sur le téléphone.
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  e.respondWith(
    fetch(e.request).then(r => { const copie = r.clone(); caches.open(VERSION).then(c => c.put(e.request, copie)); return r; })
      .catch(() => caches.match(e.request, {ignoreSearch: true}).then(r => r || caches.match('index.html')))
  );
});
